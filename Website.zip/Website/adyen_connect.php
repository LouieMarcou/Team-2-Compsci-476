POST /v68/paymentMethods HTTP/1.1
Host: checkout-test.adyen.com
Content-Type: application/json
x-API-key: AQEphmfuXNWTK0Qc+iSTnXY2ovaoQY9IJZZGSPjKMpk+TTQ+15i0biVbuDgQwV1bDb7kfNy1WIxIIkxgBw==-ZHUW3V8IloYTvdjp+uK2E52Qvj7m5h+ZiwVzv+LxpUc=-xbsP%qqM34[<?>(v